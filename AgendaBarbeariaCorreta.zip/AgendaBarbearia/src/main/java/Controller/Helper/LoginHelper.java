/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller.Helper;

import Model.Usuario;
import com.mycompany.agendabarbearia.View.Login;

/**
 *
 * @author aabrr
 */
public class LoginHelper implements IHelper {
    // Referência à view que será manipulada por este helper
    private final Login view;

    // Construtor que inicializa a view
    public LoginHelper(Login view) {
        this.view = view;
    }
    
    // Método para obter um modelo de usuário a partir dos dados da view
    @Override
    public Usuario obterModelo() {
        String nome = view.getTextUsuario().getText(); // Obtém o nome de usuário da view
        String senha = view.getTextSenha().getText(); // Obtém a senha da view
        Usuario modelo = new Usuario(0, nome, senha); // Cria um novo objeto Usuario com os dados obtidos
        return modelo;
    }

    // Método para definir os dados de um modelo de usuário na view
    public void setarModelo(Usuario modelo) {
        String nome = modelo.getNome(); // Obtém o nome do modelo de usuário
        String senha = modelo.getSenha(); // Obtém a senha do modelo de usuário
        
        view.getTextUsuario().setText(nome); // Define o campo de texto do nome de usuário na view
        view.getTextSenha().setText(senha); // Define o campo de texto da senha na view
    }
    
    // Método para limpar os campos da view
    @Override
    public void limparTela() {
        view.getTextUsuario().setText(""); // Limpa o campo de texto do nome de usuário
        view.getTextSenha().setText(""); // Limpa o campo de texto da senha
    }
}

