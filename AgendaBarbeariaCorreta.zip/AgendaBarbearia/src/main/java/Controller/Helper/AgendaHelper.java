/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller.Helper;

import Model.Agendamento;
import Model.Cliente;
import Model.Servico;
import com.mycompany.agendabarbearia.View.Agenda;
import java.util.ArrayList;
import javax.swing.DefaultComboBoxModel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author aabrr
 */
public class AgendaHelper implements IHelper{
 
//Referencia a View da Agenda    
    private final Agenda view;
//Construtor da classe Agenda Helper 
    public AgendaHelper(Agenda view) {
        this.view = view;
    }
    
//Medoto de preenchimento da tabela
    public void preencherTabelea(ArrayList<Agendamento> agendamentos) {
//Obtém o modelo da tabela         
       DefaultTableModel tableModel = (DefaultTableModel) view.getTabelaAgendamento().getModel();
       tableModel.setNumRows(0);
//For para adicionar cada agendamento na tabela, com os gets de id, nome descrição, valor, data e etc.      
       for (Agendamento agendamento : agendamentos){ 
           tableModel.addRow( new Object[]{   
               agendamento.getId(),
               agendamento.getCliente().getNome(),
               agendamento.getServico().getDescricao(),
               agendamento.getValor(),
               agendamento.getData(),
               agendamento.getHora(),
               agendamento.getObservacao()
           }
           );
       }
       }

//Coloca todos os clientes no cambo de JcomboBOx
    public void preencherCliente(ArrayList<Cliente> clientes) {
        DefaultComboBoxModel comboBoxModel = (DefaultComboBoxModel) view.getjComboBoxCliente().getModel();
//Adiciona  cada cliente no modelo de JcomboBox       
        for(Cliente cliente : clientes){
            comboBoxModel.addElement(cliente);    
        }
    }
    
//Coloca todos os serviços no cambo de JcomboBOx
    public void preencherServicos(ArrayList<Servico> servicos) {
        DefaultComboBoxModel comboBoxModel = (DefaultComboBoxModel) view.getjComboBoxServico().getModel();
//Adiciona  cada serviços no modelo de JcomboBox           
        for(Servico servico : servicos){
            comboBoxModel.addElement(servico);
        } 
    }

//Get do cliente que foi selecionado
    public Cliente obterCliente() {
       return (Cliente) view.getjComboBoxCliente().getSelectedItem();
    }
//Get do serviço que foi colocado no campo   
    public Servico obterServico() {
       return (Servico) view.getjComboBoxServico().getSelectedItem(); 
    }
//Le o serviço e coloca o valor 
    public void sertarValor(float valor) {
        view.getjTextValor().setText(valor + "");
    }
    
// Implementação do método obterModelo da interface IHelper
    @Override
    public Object obterModelo() { 
        String idString = view.getjTextId().getText();
        int id = Integer.parseInt(idString);
        Cliente cliente = obterCliente();
        Servico servico = obterServico();
        String valorString = view.getjTextValor().getText();
        float valor = Float.parseFloat(valorString);
        String data = view.getjTextData().getText();
        String hora = view.getjTextHora().getText();;
        String oberservacao = view.getjTextAreaObservacoes().getText();
// Cria um novo objeto Agendamento com os valores obtidos        
        Agendamento agendamento = new Agendamento(id, cliente, servico, valor, data, hora, oberservacao);
        return agendamento;     
    }
//Limpa os dados na tela
    @Override
    public void limparTela() {  
        view.getjTextId().setText("0");
        view.getjTextData().setText("");
        view.getjTextHora().setText("");
        view.getjTextAreaObservacoes().setText("");
    }   
}
