/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller.Helper;

/**
 *
 * @author aabrr
 */
public interface IHelper {

    // Método abstrato para obter um modelo a partir dos dados da view
    public abstract Object obterModelo();
    
    // Método abstrato para limpar os campos da view
    public abstract void limparTela();
}

