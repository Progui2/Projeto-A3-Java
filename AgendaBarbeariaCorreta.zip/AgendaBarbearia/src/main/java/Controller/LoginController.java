/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;
import Controller.Helper.LoginHelper;
import Model.DAO.UsuarioDAO;
import Model.Usuario;
import com.mycompany.agendabarbearia.View.Login;
import com.mycompany.agendabarbearia.View.Menu;
/**
 *
 * @author aabrr
 */
public class LoginController {
// Atributos que referenciam a view e um helper para manipulação de dados da view    
    private final Login view;
    private LoginHelper helper;
    
// Construtor da classe que inicializa a view e o helper    
    public LoginController(Login view){
        this.view = view;
        this.helper = new LoginHelper(view);
    }
    
//Metodo para entrar no sistema     
    public void entrarNoSistema(){
//Obtem o modelo de usuario da view        
       Usuario usuario = helper.obterModelo();
//Cria um novo usuario no DAO, que é o banco de dados        
       UsuarioDAO usuarioDAO =  new UsuarioDAO();
 //Valida o usuario      
       Usuario usuarioAutenticado = usuarioDAO.selectPorNomeESenha(usuario);
//If e else para verificar se exite o usuario no banco de dados, caso tenha o menu entra e caso não tenha fala que o Usuario ou a senha são invalidos        
       if(usuarioAutenticado != null){
           Menu menuPrincipal = new Menu();
           menuPrincipal.setVisible(true);
           this.view.dispose();
       }
       else{
           view.exibeMensagem("Usuario ou senha invalidos");
       }
       
}
    
    public void fizTarefa(){
        System.out.println("Busquei no banco de Dados");
        this.view.exibeMensagem("Executei o fiz tarefa");
        
    }
        
}
