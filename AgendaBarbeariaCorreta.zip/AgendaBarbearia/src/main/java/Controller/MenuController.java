/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import com.mycompany.agendabarbearia.View.Agenda;
import com.mycompany.agendabarbearia.View.Menu;

/**
 *
 * @author aabrr
 */
public class MenuController {

    // Referência à view que será controlada por este controller
    private final Menu view;

    // Construtor que inicializa a view
    public MenuController(Menu view) {
        this.view = view;
    }
    
    // Método para navegar para a tela de agenda
    public void navergarParaAgenda() {
        // Cria uma nova instância da tela de agenda
        Agenda agenda = new Agenda();
        
        // Torna a tela de agenda visível
        agenda.setVisible(true);
    }
}
