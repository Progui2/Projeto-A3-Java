/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Controller.Helper.AgendaHelper;
import Model.Agendamento;
import Model.Cliente;
import Model.DAO.AgendamentoDAO;
import Model.DAO.ClienteDAO;
import Model.DAO.ServicoDAO;
import Model.Servico;
import com.mycompany.agendabarbearia.View.Agenda;
import java.util.ArrayList;

/**
 *
 * @author aabrr
 */


public class AgendaController {
    
    private final Agenda view;
    private final AgendaHelper helper;
    
// Construtor da classe que inicializa a view e o helper
    public AgendaController(Agenda view) {
        this.view = view;
        this.helper = new AgendaHelper(view);
    }
    
// Método para atualizar a tabela de agendamentos na view 
    public void atulizarTabela(){
        AgendamentoDAO agendamentoDAO = new AgendamentoDAO();
// Obtém todos os agendamentos do banco de dados
        ArrayList<Agendamento> agendamentos = agendamentoDAO.selectAll();        
// Atualiza a tabela na view com os agendamentos obtidos
        helper.preencherTabelea(agendamentos);
}
    
// Método para atualizar a lista de clientes na view
    public void atualizarCliente(){
        
        ClienteDAO clienteDAO = new ClienteDAO();        
// Obtém todos os clientes do banco de dados
        ArrayList<Cliente> clientes = clienteDAO.selectAll();        
// Atualiza a lista de clientes na view   
        helper.preencherCliente(clientes);
    }
        
// Método para atualizar a lista de serviços na view        
        public void atualizarOSServico(){
            ServicoDAO servicoDAO = new ServicoDAO();
// Obtém todos os serviços do banco de dados
            ArrayList<Servico> servicos = servicoDAO.selectAll();
// Obtém todos os serviços do banco de dados            
            helper.preencherServicos(servicos);          
        }
        
 // Método para atualizar o valor do serviço selecionado na view       
        public void atualizarValor(){
// Obtém o serviço selecionado na view            
            Servico servico = helper.obterServico();
// Atualiza o valor do serviço na view           
            helper.sertarValor(servico.getValor());
        }
        
 // Método para agendar um novo serviço       
        public void agendar(){
// Obtém o modelo de agendamento da view            
            Agendamento agendamento = (Agendamento) helper.obterModelo();
// Insere o novo agendamento no banco de dad            
            new AgendamentoDAO().insert(agendamento);
 // Atualiza a tabela de agendamentos na view           
            atulizarTabela();
// Limpa os campos da tela na view            
            helper.limparTela();
        }
    }
